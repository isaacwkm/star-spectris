class Maths{

    constructor() {}

    static getRandomFloat(max, min = 0) {
        return Math.random() * (max - min) + min;
    }
}