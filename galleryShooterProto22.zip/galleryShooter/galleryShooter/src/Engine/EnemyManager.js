class EnemyManager {

    constructor(scene) {
        this.scene = scene;

        my.currFirstEnemyIndex = 0;
        this.shiftStep = 0;

        this.maxShiftStep = 6;
        this.ticksPerStep = 10;

        this.timestamps = {
            shift: 0
        }
    }


    update() {
        //console.log("LevelEditor.update()");

        this.updateShifting(my.gameRuntime);
    }

    // An update that only happens on enemy death.
    // Applicable update procedures should be placed here instead of update() to reduce processing cost.
    deathUpdate() {
        
        this.checkAndShiftRowsDown(my.gameRuntime);
    }

    levelCleanup(){
        my.currFirstEnemyIndex = 0;
    }

    checkAndShiftRowsDown(runtime) {
        //console.log("checkAndShiftRowsDown()");
        if (my.enemiesRowData[0] == 0){

            my.enemiesRowData.shift();

            if (my.level.checkStageCleared()){
                return;
            }

            const rowLen = my.settings.layout.columns;

            my.currFirstEnemyIndex += rowLen;
            this.shiftStep = 0;
            this.decrRowProperties();
            this.timestamps.shift = runtime;
            my.queue.shifting.push('q');
            this.shiftRowsDown(this.shiftStep, this.maxShiftStep);
        }
    }

    finishShiftingDown(){
        //console.log("done shifting...")
        this.shiftStep = 0;
        this.applyRowEffects();
        this.timestamps.shift = -1;
        my.queue.shifting.shift();
        my.level.updateInsertRowInQueue();
    }

    updateShifting(runtime){

        if (my.queue.shifting[0] == null){
            return;
        }
        else if(this.shiftStep == this.maxShiftStep){
            this.finishShiftingDown();
        }
        else if(runtime == this.timestamps.shift + this.ticksPerStep){
            //console.log(this.timestamps.shift);
            this.shiftRowsDown(this.shiftStep, this.maxShiftStep);
            this.timestamps.shift += this.ticksPerStep;
        }
        else{

        }
    }

    shiftRowsDown(step = 0, maxShiftStep){
        const rowLen = my.settings.layout.columns;
        this.shiftStep++;
        //console.log("shifting...");
        for (let i = 0; i < rowLen * 3; i++) {
            if (my.enemies[my.currFirstEnemyIndex + i]) {
                my.enemies[my.currFirstEnemyIndex + i].shiftRowDown(step, maxShiftStep);
            }
        }
    }

    decrRowProperties(){
        const rowLen = my.settings.layout.columns;
        let currEnemy;

        for (let i = 0; i < rowLen * 3; i++) {
            //console.log("decrRowProperties()");
            currEnemy = my.enemies[my.currFirstEnemyIndex + i];
            if (currEnemy != null) {
                currEnemy.decrRowProperty();
            }
        }
    }

    applyRowEffects() {
        const rowLen = my.settings.layout.columns;
        let row = 0;
        let currEnemy;

        for (let i = 0; i < rowLen * 3; i++) {
            row = Math.ceil((i + 1) / 9);
            currEnemy = my.enemies[my.currFirstEnemyIndex + i];

            if (currEnemy != null) {
                currEnemy.makeRowEffects(row);
            }
        }
    }
}