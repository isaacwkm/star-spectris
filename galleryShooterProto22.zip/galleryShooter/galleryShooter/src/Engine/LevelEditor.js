class LevelEditor {

    // level #
    constructor(scene, currentLevel = 0) {

        this.scene = scene;
        my.enemyBp = new EnemyBlueprint(scene, "spaceSprites1", "enemyBlue3.png", -100, -100);
        this.setMyLayoutConstants();
        my.queue.enemyRows = [];

        this.currLevel = currentLevel;
        this.levelComplete = false;
        this.enemyCount = { created: 0, alive: 0, enemiesInRow: 0 };
        this.currFirstEnemyIndex = null;

        // Spawn rates are based on how any units can appear on each row.
        // The values for each enemy type indicate (on average) how many 
        // of that enemy will appear on each row.
        this.defaultSpawnRates = {
            Blue: { key: 1, value: 6 },
            Green: { key: 2, value: 1.5 },
            Orange: { key: 3, value: 1.5 },
            BlueElite: { key: 4, value: 0 },
            GreenElite: { key: 5, value: 0 },
            OrangeElite: { key: 6, value: 0 },
            RandomElite: { key: 7, value: 0 },
            RandomNormal: { key: 8, value: 0 }
        }

        this.defaultLevelConfig = {
            // waves:
            // Arrays towards the end of the waves array are rows towards the front
            // Arrays towards the beginning of the array are rows towards the back
            // Mimics/reflects how waves will appear on-screen

            // wave values:
            // 0: empty
            // 1-3: blue/green/orange enemies 
            // 4-6: elite enemies
            // 7: random elite
            // 8: random normal
            // 9: random ANY (in SPAWNRATES). Uses spawnRates object
            waves: [
                [0, 1, 1, 0, 1, 0, 1, 1, 0],
                [0, 0, 1, 1, 1, 1, 1, 0, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 0],
                [1, 1, 1, 1, 1, 1, 1, 1, 1]
            ],
            spawnRates: [
                1,
                1,
                1,
                1
            ]
        }

        this.fetchAndStart();
    }

    async fetchAndStart() {
        //const fetch1 = await this.asyncFetch(my.levelDataUrl,);
        //const fetch2 = await this.asyncFetch(my.spawnRateDataUrl);

        my.data.levelData = await this.asyncFetch(my.levelDataUrl,);
        my.data.spawnRateData = await this.asyncFetch(my.spawnRateDataUrl);
        this.load(this.currLevel);

        //this.consoleOutputEnemies();
        //my.enemies[0].consoleOutputLinks();
    }

    async asyncFetch(url) {
        const response = await fetch(url);
        return response.json();
    }

    consoleOutputEnemies() {
        for (let enemy of my.enemies) {
            console.log(enemy);
        }
    }

    setMyLayoutConstants() {
        // y-axis offset to space enemies apart from other rows
        let offsetY;

        for (let i = 2; i <= 4; i++) {
            offsetY = (my.enemyBp.displayHeight + 10);
            // location constants on screen
            my.settings.layout.yAxisOfRow[i] = my.settings.layout.yAxisOfRow[i - 1] - offsetY;
        }
    }

    updateInsertRowInQueue() {
        if (my.level.enemyCount.alive == 0) { //if last enemy is killed
            this.updateLevelCheck(true);
        }
        else {
            this.enemyCount.enemiesInRow = 0;
            if (my.queue.enemyRows[0]) {
                this.expandingRowCreate(my.queue.enemyRows[0], 4);
                my.enemiesRowData.push(this.enemyCount.enemiesInRow); // push enemy count for current row
            }
            my.queue.enemyRows.shift();
        }
    }

    levelCompleteCleanup() {
        my.enemies = [];
        my.enemiesRowData = [];
        my.queue = { enemyRows: [], shifting: [] };
        my.flags = { enemiesShifting: false };
        my.enemyMan.levelCleanup();
    }

    updateLevelCheck(levelCompleteFlag = this.levelComplete) {
        if (levelCompleteFlag == true) {
            this.levelCompleteCleanup();
            console.log("LEVEL " + this.currLevel + " COMPLETE!");
            this.load(++this.currLevel);
        }
    }

    checkStageCleared() {
        if (this.enemyCount.alive == 0) {
            this.updateLevelCheck(true);
            return true;
        }
        else {
            return false;
        }
    }

    load(level = 0) { // uses json data (started with trying a switch case, haha). Level index corresponds to json data's level data.
        console.log("LevelEditor.load() " + level);

        this.currLevel = level;
        if (my.data.levelData.Levels[level] == null){
            console.log("Victory!")
            return
        }
        else if (my.data.levelData.Levels[level].victory == true){
            console.log("Victory!")
            return
        } 

        // This is the config object format
        let levelConfig = { waves: [], spawn: [] };
        //console.log("Level " + level + " data:");
        //console.log(my.data.levelData.Levels[level].waves);
        //console.log(my.data.levelData.Levels[level].spawnRates);

        levelConfig.waves = my.data.levelData.Levels[level].waves;
        levelConfig.spawnRates = my.data.levelData.Levels[level].spawnRates;

        this.loadLevel(levelConfig.waves, levelConfig.spawnRates);

        //console.log("LevelEditor.load() end");

        return;
    }

    loadLevel(waveConfig = this.defaultLevelConfig.waves, spawnConfig = this.defaultLevelConfig.spawnRates) {
        //console.log("LevelEditor.loadLevel()");
        //console.log("spawnConfig = " + spawnConfig);
        let waves = waveConfig.length;
        for (let i = waves - 1; i >= 0; i--) {
            //console.log("i, waveconfigi, spawnconfigi, waves-1");
            this.createRow(waveConfig[i], spawnConfig[i], waves - i);
        }
    }

    // createRow(): A powerful function that creates an entire row of enemies on screen.
    // If the screen is full with max amount of rows, creates a row in an off-screen queue.
    // Has a lot of helper functions to get its job done
    // When initially creating visible rows of enemies, row = 1, 2, 3, etc. Afterwards, new rows are created on the last row + 1 (offscreen)
    createRow(waveArray, spawnPreset = 1, rowOnScreen = 1) {
        //console.log("LevelEditor.createRow(waveArray, spawnPreset, rowOnScreen)");
        //console.log("spawnPreset = " + spawnPreset);

        // keep track of how many enemies are actually created in this row
        this.enemyCount.enemiesInRow = 0;

        // see spawnRateData.json for spawnRate presets
        let fetchedSpawnRates = my.data.spawnRateData.spawnRatePresets[spawnPreset];
        //console.log("fetchedSpawnRates = " + fetchedSpawnRates);

        // convertedSpawnRates reformats the fetched spawn rates to a format more friendly
        // for the random generator to work with

        // First, we convert the spawn rates
        let convertedSpawnRates = this.convertSpawnRates(fetchedSpawnRates);

        // Second, we convert the wave array using the converted spawn rates
        let convertedWave = this.convertWave(waveArray, convertedSpawnRates);

        // Creation of each enemy in the row

        if (this.expandingRowCreate(convertedWave, rowOnScreen)) {
            my.enemiesRowData.push(this.enemyCount.enemiesInRow); // push enemy count for current row
        }
    }


    expandingRowCreate(convertedWaveArr, rowOnScreen) {
        //console.log("expandingRowCreate()");
        //console.log("convertedWave: " + convertedWaveArr);
        let cap = my.settings.layout.columns;
        if (cap % 2 == 0) {
            throw "Error - expandingRowCreate(): Expanding Row Creation procedure does not work with an even number of enemies per row";
        }

        if (rowOnScreen >= 5) {
            // create row off-screen
            //console.log("row created off-screen");
            this.queueRow(convertedWaveArr);
            return false;
        }

        // x-axis offset to space enemies apart from other enemies on the same row
        const offsetX = (my.enemyBp.displayWidth + 10);

        // location constants on screen
        const rowY = my.settings.layout.yAxisOfRow[rowOnScreen];
        const midX = my.settings.positions.MiddleOfScreenX;

        // Create array iterator (index) and set it to the middle of the array
        const midIndex = (Math.floor(cap / 2));
        let index = midIndex;

        let x = midX;

        // "enemiesCreated" increases every time an enemy is created in the loop below.
        // This value is used to access the array's indexes starting from the middle -> outwards.
        let enemiesCreated = 0;

        // Create first enemy of the row in the center of the screen, at the Y coordinate of the specified row
        this.createEnemy(convertedWaveArr[index], x, rowY, rowOnScreen);

        //console.log("expandingRowCreate's whileLoop");

        index += ++enemiesCreated;

        while (convertedWaveArr[index] != undefined) { // While loop terminates after adding the last enemy of the row (no more indices in the array to traverse)
            // Each iteration of the while loop creates an enemy on both ends of the row.

            // Right-side of the row
            x += (offsetX * enemiesCreated);
            //console.log("convertedWaveArr[Index] = " + convertedWaveArr[index] + ", index = " + index);
            this.createEnemy(convertedWaveArr[index], x, rowY, rowOnScreen);

            index -= ++enemiesCreated;

            // Left-side of the row
            x -= (offsetX * enemiesCreated);
            //console.log("convertedWaveArr[Index] = " + convertedWaveArr[index] + ", index = " + index);
            this.createEnemy(convertedWaveArr[index], x, rowY, rowOnScreen);

            index += ++enemiesCreated;
        }

        return true;
    }

    queueRow(convertedWaveArr) {
        my.queue.enemyRows.push(convertedWaveArr);
    }

    convertSpawnRates(spawnRates = this.defaultSpawnRates) {
        //console.log("LevelEditor.convertSpawnRates(spawnRates)");
        //console.log("spawnRates = " + spawnRates);
        let convertedSpawnRates = {};
        let spawnRateTotal = 0;
        let it = 1;

        for (let enemyUnparsed in spawnRates) {
            let enemy = JSON.stringify(enemyUnparsed);
            enemy = this.removeQuotationsFromString(enemy);
            //console.log("enemy: " + enemy);

            // create new property object
            convertedSpawnRates[enemy] = {};

            // set .key
            convertedSpawnRates[enemy].key = it

            // set .lower range
            convertedSpawnRates[enemy].lowerRange = spawnRateTotal;

            // Increase spawn rate total for upper range value
            spawnRateTotal += spawnRates[enemy].value;

            // set .upper range
            convertedSpawnRates[enemy].upperRange = spawnRateTotal;

            // increment iterator for setting key
            it++;

            // debug
            //console.log(convertedSpawnRates[enemy]);
        }

        // Checking for invalid spawn rates
        if (spawnRateTotal != my.settings.layout.columns) { // Spawn rates should add up to how many units can appear on a row
            //console.log(spawnRateTotal);
            //console.log(spawnRateTotal);
            //console.log(spawnRates);
            throw "convertSpawnRates() - Error: spawn rates add up to over or under the target (target is equal to the number of columns visible)";
        }

        return convertedSpawnRates;
    }

    removeQuotationsFromString(str) {
        let newStr = ""
        for (let i = 1; i < str.length - 1; i++) {
            newStr += str[i];
        }
        return newStr;
    }

    // convertWave(array, spawnrates object)
    // Random enemy generation begins with assigning a unique range to each enemy type
    // and creating the enemy of the range in which the random number was created.
    convertWave(unconvertedWaveArray, convertedSpawnRates) {
        //console.log("convertWave()");
        //console.log("unconvertedWaveArray: " + unconvertedWaveArray);
        let convertedWaveArray = [];
        let myEnemyType = "";
        let target = 0;
        let targetMax = my.settings.layout.columns;

        for (let i = 0; i < unconvertedWaveArray.length; i++) {
            myEnemyType = "";
            target = Maths.getRandomFloat(targetMax);
            //console.log("unconvertedWaveArray[i]: " + unconvertedWaveArray[i]);
            switch (unconvertedWaveArray[i]) {

                case 9: // 9: random ANY (uses row spawnRates object)
                    for (let property in convertedSpawnRates) {
                        if (convertedSpawnRates[property].lowerRange <= target && target < convertedSpawnRates[property].upperRange) {
                            myEnemyType = convertedSpawnRates[property].key;
                        }
                    }
                    convertedWaveArray[i] = myEnemyType;
                    break;

                case 8: // 8: random normal
                    if (target < (targetMax / 3)) {
                        myEnemyType = 1;
                    }
                    else if (target < (targetMax / 3) * 2) {
                        myEnemyType = 2;
                    }
                    else {
                        myEnemyType = 3;
                    }
                    convertedWaveArray[i] = myEnemyType;
                    break;

                case 7: // 7: random elite
                    if (target < (targetMax / 3)) {
                        myEnemyType = 4;
                    }
                    else if (target < (targetMax / 3) * 2) {
                        myEnemyType = 5;
                    }
                    else {
                        myEnemyType = 6;
                    }
                    convertedWaveArray[i] = myEnemyType;
                    break;

                default:
                    //console.log("default statement: LevelEditor.convertWave()");
                    convertedWaveArray[i] = unconvertedWaveArray[i];
            }
        }

        return convertedWaveArray;
    }

    // createEnemy() creates an enemy of a specified type
    // creating an enemy requires the following data: scene, texture, frame, x, y, rowOnScreen, propertyObj
    // handled by this class' properties: scene
    // handled by other functions, present in this function's parameters: x, y, row
    // handled in this function: texture, frame, (using type parameter to perform switch/case)
    // handled by other class properties: propertyObj (in class Enemy's child classes)
    createEnemy(type, x, y, row) {
        //console.log("createEnemy()");
        let obj;

        const rowLength = my.settings.layout.columns;
        const enemyCount = my.enemies.length;
        const enemyInFrontIndex = enemyCount - rowLength;
        let index = my.enemies.length;

        switch (type) {
            case 0: // 0 indicates no enemy should be created and an empty spot should be left.
                obj = null;
                my.enemies.push(obj);
                return;

            case 1:
                obj = new EnemyBlue(this.scene, "spaceSprites1", "enemyBlue3.png", x, y, index, row);
                break;

            case 2:
                //obj = new EnemyGreen(this.scene, "spaceSprites1", "enemyBlue3.png", x, y, row);
                break;

            case 3:
                obj = new EnemyOrange(this.scene, "spaceSprites1", "enemyOrange3.png", x, y, index, row);
                break;

            case 4:

                break;

            case 5:

                break;

            case 6:

                break;

            default:
                console.log(`default statement: LevelEditor.createEnemy(). type: ` + type);
                return;
        }

        let objInFront = my.enemies[enemyInFrontIndex];
        let objTwoRowsInFront = my.enemies[enemyInFrontIndex - rowLength];

        if (objInFront) { // if there is an enemy that exists in front of the enemy that is being created:
            obj.properties.allyInFront = objInFront; // link the current enemy to its ally in front of it
            objInFront.properties.allyBehind = obj; // link the current enemy to its ally in front of it
        }
        else if (objTwoRowsInFront) { //if there is an enemy that exists two rows in front of the enemy that is being created:
            obj.properties.allyInFront = objTwoRowsInFront; // link the current enemy to its ally in front of it
            objTwoRowsInFront.properties.allyBehind = obj; // link the current enemy to its ally in front of it
        }
        my.enemies.push(obj);
        this.incrEnemyCount();
    }

    incrEnemyCount() {
        for (let property in this.enemyCount) {
            this.enemyCount[property]++;
        }
    }

    decrEnemyAliveCount() {
        this.enemyCount.alive--;
    }
}

