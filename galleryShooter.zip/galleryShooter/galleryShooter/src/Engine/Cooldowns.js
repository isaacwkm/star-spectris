class Cooldowns{

    // level #
    constructor(level, defaultLevel = true, rows = 4) {
    }
}