class GameConfig extends Phaser.Scene {
    constructor() {
        super("gameConfig");
        
        // Constants for starting positions
        my.settings.positions.MiddleOfScreenX = 400;
        my.settings.positions.PlayerShipYAxis = 500;
        my.settings.positions.MiddleOfScreenY = 300;

        // Key bindings
        my.settings.keybindings.moveLeft = "A";
        my.settings.keybindings.moveRight = "D";
        my.settings.keybindings.fire = "SPACE";

        // Movement
        my.settings.movement.playerSpeed = 12;

        // Projectiles
        my.settings.projectiles.maxPlayerBullets = 12;

        // Enemy Layout
        my.settings.layout.columns = 9;
        my.settings.layout.yAxisOfRow[1] = 150;

        // Cooldown
        my.cooldowns.player = {};
        my.cooldowns.player.fire = 0;

    }

    // Use preload to load art and sound assets before the scene starts running.
    preload() {

        this.load.setPath("./assets/");

        // Load sprite atlas
        this.load.atlasXML("spaceSprites1", "sheet.png", "sheet.xml");
        this.load.atlasXML("spaceSprites2", "spaceShooter2_spritesheet.png", "spaceShooter2_spritesheet.xml");
        
        // Load .pngs
            // Background
        this.load.image("purple_background", "purple.png");
        this.load.image("darkPurple_background", "darkPurple.png");
            // Laser anims
        this.load.image("laserRed08", "laserRed08.png");
        this.load.image("laserRed09", "laserRed09.png");
        this.load.image("laserBlue08", "laserBlue08.png");
        this.load.image("laserBlue09", "laserBlue09.png");
        this.load.image("laserGreen14", "laserGreen14.png");
        this.load.image("laserGreen15", "laserGreen15.png");

        // update instruction text
        document.getElementById('description').innerHTML = '<h2>Controls: <br>A - move left // D - move right // SPACE - shoot</h2>'

        // Font
        this.load.bitmapFont("rocketSquare", "KennyRocketSquare_0.png", "KennyRocketSquare.fnt");

        // Sound assets
        this.load.audio("playerLaserShoot", "laserSmall_000.ogg");
        this.load.audio("metalHit", "impactMetal_002.ogg");
        this.load.audio("boom", "explosionCrunch_000.ogg");
        this.load.audio("boom_echo", "explosionCrunch_echo.ogg");

        
        
        
    }

    create() {

        //      // Scene/Level
        //
        //
        //

        //      // Player Model
        //
        //
        //

        //      // Enemies
        //
        //
        //      
        
        //      // Projectiles
        //
        //
        //      
        
        //      // Effects/Animations
        //
        //
        //

        my.anims.redLaserHit = {
            key: "redLaserHitConfirm",
            frames: [
                { key: "laserRed09" },
                { key: "laserRed08" },
            ],
            frameRate: 8,
            repeat: 0,
            hideOnComplete: true
        };

        my.anims.blueLaserHit = {
            key: "blueLaserHitConfirm",
            frames: [
                { key: "laserBlue08" },
                { key: "laserBlue09" },
            ],
            frameRate: 5,
            repeat: 5,
            hideOnComplete: true
        };

        my.anims.greenLaserHit = {
            key: "greenLaserHitConfirm",
            frames: [
                { key: "laserGreen14" },
                { key: "laserGreen15" },
            ],
            frameRate: 20,
            repeat: 5,
            hideOnComplete: true
        };
        

        // Move to next scene
        this.scene.start("level");
    
    }

    update() {

        //update() should never be reached, as this scene is the config/setup/preload scene.
    }
}