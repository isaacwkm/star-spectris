class MouseSmiley extends Phaser.Scene {
    constructor() {
        super("mouseSmiley");

    }

    // Use preload to load art and sound assets before the scene starts running.
    preload() {

    }

    create() {

    }

    update() {
    }

}