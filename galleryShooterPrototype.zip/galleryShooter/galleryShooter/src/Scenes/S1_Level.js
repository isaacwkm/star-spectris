class Level extends Phaser.Scene {
    constructor() {
        super("level");

    }

    // Use preload to load art and sound assets before the scene starts running.
    preload() {

    }

    create() {

        //      // Scene
        //
        //
        //

        let midX = my.settings.positions.MiddleOfScreenX;
        let midY = my.settings.positions.MiddleOfScreenY;
        this.background = this.add.tileSprite(midX, midY, 800, 600, "purple_background");

        //      // Player Model
        //
        //
        //

        my.players.playerShip = new Player(this, "spaceSprites1", "playerShip1_red.png");
        // Visible from the start:
        //my.players.playerShip.visible = true;

        //      // Enemies
        //
        //
        //      

        my.enemies[0] = new EnemyBlue(this, "spaceSprites1", "enemyBlue3.png");
        
        

        //      // Projectiles
        //
        //
        //      

        // making player projectiles

        my.projectilesPlayer = {};
        for (let i = 0; i < my.settings.projectiles.maxPlayerBullets; i++){
            my.projectilesPlayer[i] = new Bullet(this, "spaceSprites1", "laserRed16.png", 12);
        }

        // Resetting some global variables:
        my.cooldowns.player = {};
        my.cooldowns.player.fire = 0;

        //      // Effects/Animations
        //
        //
        //    
        
        this.anims.create(my.anims.redLaserHit);
        this.anims.create(my.anims.blueLaserHit);
        this.anims.create(my.anims.greenLaserHit);
    }

    update() {

        // Scrolling Background
        this.background.tilePositionY -= 1;

        // Decrement all cooldown counters
        this.updateCooldowns();

        // Polling Input
        my.players.playerShip.update();

        // Update enemies
        my.enemies[0].update();

        // Update bullets
        for (let bullet in my.projectilesPlayer){
            my.projectilesPlayer[bullet].update();
        }
        
        //this.consoleDebug(); // debugging messages in console
    }

    // updateCooldowns(): reducing cooldown count of all cooldowns (player, enemy, specials)
    updateCooldowns(){
        let entityObj = null;
        for (let entity in my.cooldowns){ // entity: player, enemy, etc.
            entityObj = my.cooldowns[entity];
            for (let cd in entityObj){ // cd: fire, shield, etc.
                entityObj[cd] -= 1;
            }
        }
    }

}