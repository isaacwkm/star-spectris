class LevelEditor{

    // level #
    constructor(level, defaultLevel = true, rows = 4) {
        this.level = level;
        this.enemies = [];
        this.rowsCreated = 0;
        // Spawn rates are based on how any units can appear on each row.
        // The values for each enemy type indicate (on average) how many 
        // of that enemy will appear on each row.
        this.enemyList[
            "Blue",
            "BlueElite",
            "Green",
            "GreenElite",
            "Orange",
            "OrangeElite",
            "RandomElite"
        ];
        this.defaultSpawnRates = {
            Blue: 4,
            BlueElite: 0,
            Green: 1.5,
            GreenElite: 0,
            Orange: 1.5,
            OrangeElite: 0,
            RandomElite: 0.25
        }

        if (defaultLevel == true) {
            for (let i = 0; i < 4; i++){
                this.createRow(defaultSpawnRates);
            }
        }

        this.rows = rows;
        this.columns = my.settings.layout.columns;
    }

    // testing required
    createRow(enemySpawnRates = this.defaultSpawnRates){

        let spawnRateTotal = 0;
        let highestRate = {key: "Blue", rate: 0};

        // Random enemy generation begins with assigning a unique range to each enemy type
        // and creating the enemy of the range in which the random number was created.
        let convertedSpawnRates = {ExampleEnemy: {lowerRange: 0, higherRange: 0}};
        // convertedSpawnRates reformats the enemySpawnRates to a format more friendly
        // for the random generator to work with

        for (let enemy in enemySpawnRates){
            if (enemySpawnRates[enemy] > highestRate.rate){
                highestRate.key = enemy;
                highestRate.rate = enemySpawnRates[enemy];
            }
            convertedSpawnRates[enemy] = {};
            convertedSpawnRates[enemy].lowerRange = spawnRateTotal;
            spawnRateTotal += enemySpawnRates[enemy];
            convertedSpawnRates[enemy].upperRange = spawnRateTotal;
        }
        
         // Checking for invalid spawn rates
        if (spawnRateTotal != my.settings.columns){ // Spawn rates should add up to how many units can appear on a row
            console.log(enemySpawnRates);
            throw "Error: spawn rates add up to over or under 1";
        }

        // Creation of each enemy in the row
        for (let i = 0; i < this.columns; i++){

            // call createEnemy()

            let myEnemyType = "";
            let target = this.getRandomFloat(my.settings.layout.columns)
            for (let property in convertedSpawnRates){
                if (convertedSpawnRates[property].lowerRange < target && target < convertedSpawnRates[property].upperRange){
                    myEnemyType = property;
                }
            }
            this.enemies[this.rowsCreated][i] = myEnemyType;
        }

        this.rowsCreated++;
    }

    createEnemy(enemySpawnRates = this.defaultSpawnRates, row = this.rowsCreated, column = this.enemies[this.rowsCreated.length]){

    }

    getRandomFloat(max, min = 0) {
        return Math.random() * (max - min) + min;
      }

}