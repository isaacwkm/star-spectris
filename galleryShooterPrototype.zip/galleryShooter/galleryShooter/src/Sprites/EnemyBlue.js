class EnemyBlue extends Enemy {

    // x,y - starting sprite location
    // spriteKey - key for the sprite image asset
    constructor(scene, texture, frame, x = my.settings.positions.MiddleOfScreenX, y = 200) {
        super(scene, texture, frame, x, y);

        return this;
    }
}