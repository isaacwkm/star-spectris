class Enemy extends Phaser.GameObjects.Sprite {

    // x,y - starting sprite location
    // spriteKey - key for the sprite image asset
    constructor(scene, texture, frame, x = my.settings.positions.MiddleOfScreenX, y = 200) {
        super(scene, x, y, texture, frame);

        this.setScale(0.70);
        scene.add.existing(this);

        this.scene = scene;

        this.properties = {
            state: "dead", // alive, dying, dead, inactive
            type: "shielder", // shielder, shielderElite, fighter, fighterElite, bomber, bomberElite, stealthCaptain, stealthBomber
            // shielder: shoots at a normal pace and takes breaks periodically to shield itself while not shooting
            // shielderElite: Shields itself and allies and lowers its shield briefly to fire multiple round bursts
            // fighter: shoots fast lasers towards the player
            // for more info, check design doc
            health: 60,
            movementMode: "idle", // idle, strafing, re-entry, immobile
            shootMode: "idle", // idle, shooting, cooldown
            shootCooldown: 6, //seconds

        }

        return this;
    }

    update() {

        this.checkCollision();
    }

    // Check for collision with the enemy
    checkCollision(){
        for (let bullet in my.projectilesPlayer){
            let b = my.projectilesPlayer[bullet];
            if (this.collides(this, b)) {
                // start animation
                this.hitAnim = this.scene.add.sprite(b.x, b.y - 30, "laserRed08").setScale(0.5).play("redLaserHitConfirm");
                // clear out bullet -- put y offscreen, will get reaped next update
                b.y = -100;
                //this.loseHP();
                // Update score
                //this.updateScore();
                // Play sound
                this.scene.sound.play("metalHit", {
                    volume: 1   // Can adjust volume using this, goes from 0 to 1
                });
                // Potentially do something after end of animation
                this.hitAnim.on(Phaser.Animations.Events.ANIMATION_COMPLETE, () => {
                    // do something
                }, this);
    
            }
        }
    }

    collides(a, b) {
        if (Math.abs(a.y - b.y) > (a.displayHeight/2 + b.displayHeight/2)) return false;
        if (Math.abs(a.x - b.x) > (a.displayWidth/2 + b.displayWidth/2)) return false;
        return true;
    }
    

    createEnemy(type = "Blue"){
        switch (type) {
            case 'Blue':
                break;
            case 'BlueElite':
                break;
            case 'Green':
                break;
            case 'GreenElite':
                break;
            case 'Orange':
                break;
            case 'OrangeElite':
                break;
            default:
              console.log(`default statement: createEnemy()`);
          }
    }
}