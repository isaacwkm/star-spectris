class Enemy extends Phaser.GameObjects.Sprite {

    // x,y - starting sprite location
    // spriteKey - key for the sprite image asset
    // leftKey - key for moving left
    // rightKey - key for moving right
    constructor(scene, texture, frame, x = my.settings.positions.MiddleOfScreenX, y = 200,) {
        super(scene, x, y, texture, frame);
        scene.add.existing(this);

        this.properties = {
            state: "dead", // alive, dying, dead, inactive
            type: "shielder", // shielder, shielderElite, fighter, fighterElite, bomber, bomberElite, stealthCaptain, stealthBomber
            // shielder: shoots at a normal pace and takes breaks periodically to shield itself while not shooting
            // shielderElite: Shields itself and allies and lowers its shield briefly to fire multiple round bursts
            // fighter: shoots fast lasers towards the player
            // for more info, check design doc
            health: 60,
            movementMode: "idle", // idle, strafing, re-entry, immobile
            shootMode: "idle", // idle, shooting, cooldown
            shootCooldown: 6, //seconds

        }

        return this;
    }

    update() {}
}