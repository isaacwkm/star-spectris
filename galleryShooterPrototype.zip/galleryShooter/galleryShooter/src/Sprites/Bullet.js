class Bullet extends Phaser.GameObjects.Sprite {
    constructor(scene, texture, frame, speed, x = 0, y = 0,) {        
        super(scene, x, y, texture, frame);
        this.visible = false;
        this.active = false;
        this.bulletSpeed = speed;
        this.scene = scene;

        scene.add.existing(this);

        return this;
    }
   
    // updatePlayerBullets(): update trajectory of player's fired lasers
    update(){
        if (this.active) {
            this.y -= this.bulletSpeed;
            if (this.y < -(this.displayHeight/2)) {
                this.makeInactive();
            }

        }
    }

    makeActive() {
        // Play sound
        this.scene.sound.play("playerLaserShoot", {
            volume: 0.4   // Can adjust volume using this, goes from 0 to 1
        });
        this.visible = true;
        this.active = true;
    }

    makeInactive() {
        this.visible = false;
        this.active = false;
    }

}