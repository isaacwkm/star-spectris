// Isaac Kim
// Created: 5/13/2024
// Phaser: 3.70.0
//
// 1-D Movement
//
//
// 
// Art assets from Kenny Assets "Shape Characters" set:
// https://kenney.nl/assets/shape-characters

// debug with extreme prejudice
"use strict"

// game config
let config = {
    parent: 'phaser-game',
    type: Phaser.CANVAS,
    render: {
        pixelArt: true  // prevent pixel art from getting blurred when scaled
    },
    width: 800,
    height: 600,
    fps: { forceSetTimeOut: true, target: 60 },
    scene: [GameConfig, Level]
}

// global objects
var my = {
    players: {}, 
    enemies: {}, 
    projectilesPlayer: {}, 
    projectilesEnemy: {}, 
    anims: {}, 
    text: {}, 
    cooldowns: {player: {fire: 0}}, 
    levelConfig: {}, 
    score: {},
    settings: {
        positions: {MiddleOfScreenX: 0, PlayerShipYAxis: 0, MiddleOfScreenY: 0 }, // Constants for starting positions
        keybindings: {moveLeft: "", moveRight: "", fire: ""}, // Key bindings
        movement: {playerSpeed: 0}, // Movement
        projectiles: {maxPlayerBullets: 0}, // Projectiles
        layout: {columns: 0} // Layout
    }};

const game = new Phaser.Game(config);